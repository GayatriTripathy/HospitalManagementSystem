# Hospital-Management-System
Java mini project Hospital Management System with SQL database.
To run this properly use wampserver or another sql server and creat table and database according to project code or modify code accordings to your database & table name.

Note: This is not licensed for marketing or republishing, but you can use it for your personal work. copyright is strictly prohibited.
